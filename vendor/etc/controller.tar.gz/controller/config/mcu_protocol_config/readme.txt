﻿
/*
 * ModeID说明
 */
0x1501-5377   ：MX6000
0xA400-41984  : 4xHDMI2.0 InputCard
0xA440-42048  : 4x10GSFP  OutputCard
0xA441-42049  : 1x40GSFP  OutputCard
0xA480-42112  : 背板