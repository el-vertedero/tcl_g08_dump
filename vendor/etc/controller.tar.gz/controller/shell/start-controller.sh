#!/bin/sh
CONTROLLER_PATH=/oem/controller


cd $CONTROLLER_PATH
crash $CONTROLLER_PATH/NeoController > /dev/null 2>&1 &


return 0
