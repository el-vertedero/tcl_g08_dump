# eg: ./analysis.sh [日志等级:info\error\warn] [条数:10]
# 默认 info 10条

cd /userdata/log/controller/
tmpPath="/tmp/log/"
log=$tmpPath"tmp.log"

function creatTmp {
        touch $1
        chmod a+x $1
}

function rmTmp {
        rm -f $1
}

function ungz2Tmp {
        for gz in `ls *.log.gz`; do
                zcat $gz >> $log
        done
        cat "controller.log" >> $log
}

function paramInit {
        filter="$(echo ${1} | tr 'a-z' 'A-Z')"
        n=$2

        if [ -z $filter ]
        then
                filter='INFO'
        fi

        if [ -z $n ]
        then
                n=10
        fi
}

function printData {
        cat $log | grep $filter | awk -F ' ' '{print $6}' | sort | uniq -c | sort -nr | head -n $n
        printf '\n------- message times: \n'
        cat $log | grep $filter | awk -F ' ' '{for(i=1; i<=6; i++){$i=""} ;print $0}' | sort | uniq -c | sort -nr | head -n $n
}

paramInit $1 $2
creatTmp $log
ungz2Tmp
printData
rmTmp $log
