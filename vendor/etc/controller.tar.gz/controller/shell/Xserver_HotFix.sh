#!/bin/sh

#$1: 产品型号
#$2: 当前版本
#$3: 升级版本

echo "Xserver_HotFix $1 $2 $3"
#版本回退
if [ "$1" == "cx80" ] && [[ "$2" == V1.3* ]] && [[ "$3" == V1.1* ]]; then
          echo "hotFix deviceConfig"
          rm -rf /userdata/controller/usrconfig/*
fi