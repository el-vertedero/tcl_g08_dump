#!/bin/sh
CONTROLLER_PATH=/oem/controller


killall -9 NeoController
sleep 1

cd $CONTROLLER_PATH
$CONTROLLER_PATH/NeoController > /dev/null 2>&1 &


return 0
