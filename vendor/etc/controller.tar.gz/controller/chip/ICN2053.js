// Copyright (C) 2019 The Nova Company Ltd.All rights reserved.

var getGainFlag = 0x03fe;    // 读电流增益标志
var setGainFlag = 0x03fe;    // 写电流增益标志

// 固有属性
var chipBaseProp = {
    IsLowGray: false
};


/**
 * 获取XBit数据
 * @return {string}
 */
function getXBitData() {
    var xBitData = {
        XBitFlag: 0,
        IsXBitGrayDepth: true,
        XBitGrayDepth: 16
    };
    return JSON.stringify(xBitData);
}

/**
 * 获取芯片固有属性
 * @return {string}
 */
function getBaseProp() {
    return JSON.stringify(chipBaseProp);
}

/**
 * 从寄存器值中获取电流增益
 * @param chipRegGroupList 寄存器组列表
 * @return {string} RGB 电流增益
 */
function getGainByRegister(chipRegGroupList) {
    if (chipRegGroupList.length !== chipBaseProp.RegGroupCnt) {
        return "";
    }

    var gain = {
        r: chipRegGroupList[1].r & getGainFlag,
        g: chipRegGroupList[1].g & getGainFlag,
        b: chipRegGroupList[1].b & getGainFlag
    };
    return JSON.stringify(gain);
}

function getRegisterAddrMapping() {
    var len = 8 * chipBaseProp.RegGroupCnt;
    var regs = [{
        RegIndex: 0,
        Addr: 0x1B000000,
        DataLength: len
    }];
    return JSON.stringify(regs);
}

function getRegisterGroup(reg, data) {
    if (reg.DataLength !== data.length && reg.DataLength !== 8 * chipBaseProp.RegGroupCnt) {
        return ""
    }

    var regs = [];
    for (i = 0; i < chipBaseProp.RegGroupCnt; i++) {
        var red = data[i * 8] & 0xFF | data[i * 8 + 1] & 0xFF << 8;
        var green = data[i * 8 + 2] & 0xFF | data[i * 8 + 3] & 0xFF << 8;
        var blue = data[i * 8 + 4] & 0xFF | data[i * 8 + 5] & 0xFF << 8;

        var tReg = {
            r: red,
            g: green,
            b: blue
        };
        regs.push(tReg);
    }
    return JSON.stringify(regs);
}