// Copyright (C) 2019 The Nova Company Ltd.All rights reserved.

var getGainFlag = 0x003f;    // 读电流增益标志
var setGainFlag = 0x003f;    // 写电流增益标志

// 固有属性
var chipBaseProp = {
    IsLowGray: false
};


/**
 * 获取XBit数据
 * @return {string}
 */
function getXBitData() {
    var xBitData = {
        XBitFlag: 1,
        IsXBitGrayDepth: true,
        XBitGrayDepth: 16
    };
    return JSON.stringify(xBitData);
}

/**
 * 获取芯片固有属性
 * @return {string}
 */
function getBaseProp() {
    return JSON.stringify(chipBaseProp);
}

/**
 * 从寄存器值中获取电流增益
 * @param chipRegGroupList 寄存器组列表
 * @return {string} RGB 电流增益
 */
function getGainByRegister(chipRegGroupList) {
    if (chipRegGroupList.length !== chipBaseProp.RegGroupCnt) {
        return "";
    }

    var gain = {
        r: chipRegGroupList[0].r & getGainFlag,
        g: chipRegGroupList[0].g & getGainFlag,
        b: chipRegGroupList[0].b & getGainFlag
    };
    return JSON.stringify(gain);
}

function getRegisterAddrMapping() {
    return "[]";
}

function getRegisterGroup(reg, data) {
    return "";
}